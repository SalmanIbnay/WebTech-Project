<!DOCTYPE HTML>
<html>
     <head><title> Online Shopping main page</title>
     
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
     <link rel="stylesheet" href="style1.css">
     <link rel="stylesheet" href="style1.css" />
     <script src ="store.js" async></script>

     <!-- jQuery library -->
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
     <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

     </head>

        <body>
             <div id="top">
                 <div class="container">
                      <div class="col-md-6 offer">
                          <a href="#" class="btn btn-success btn-sm"> Welcome Guest</a>
                          <a href="#"> </a>
                      </div>
                      <div class="col-md-6">
                         <ul class="menu">
                              
                         </ul>
                      </div>
                 </div>
             </div>

             <div class " navbar navbar-default" id="navbar">
             
               <div class="container">
                  <div class="navbar-header">
                    <a class="navbar-brand home" href="index.php">
                      <left> <img src="image/logo.jpg" height="40" align="left" /> </left>
                    </a>
                  <button type="button" class ="navbar-toggle" data-toggle="collapse" data-target="#navigation">
                  <span class="sr-only">Toggle Navigation</span>
                  <i class="fa fa-align-justify"> </i>
                  </button>
                  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#search">
                  <span class="sr-only"></span>
                  <i class ="fa fa-search"> </i>
                  </button>  

                  </div><!---navbar header strt----->
                  <div class="navbar-collapse collapse" id="navigation"> 
                  
                    <div class="padding-nav">

                    <ul class="nav navbar-nav navbar-left">

                       <li class="active">
                          <a href="index.php"> Home </a>
                       </li>
                       


                    </ul>
                    </div>
                    
                    
                    
                    
                    
                    
                    
                    </form>
                        
                    
                    </div>


                  </div>
               </div>
             
             </div>

       <!-----slider-------->


       <div class ="container " id="slider">
       <div class="col-md-12">

          <div class="carousel slide" id="myCarousel" data-ride="carousel">

          <ol class="carousel-indicators">

              <li data-target="myCarousel" data-slide-to="0" class="action"></li>
              <li data-target="myCarousel" data-slide-to="1" ></li>
              <li data-target="myCarousel" data-slide-to="2" ></li>
              <li data-target="myCarousel" data-slide-to="3" ></li>
          
          
          </ol>

          <div class="carousel-inner">
          <div class="item active">
            <img src="image/offer.gif" height="2000" width="2000">
             
          </div>

          <div class="item ">
            <img src="image/offer1.jpg" height="2000" width="2000">
             
          </div>
          <div class="item">
            <img src="image/offer2.jpg" height="2000" width="2000">
             
          </div>
          <div class="item">
            <img src="image/offer3.jpg" height="2000" width="2000">
             
          </div>
          <div class="item ">
            <img src="image/offer4.jpg" height="2000" width="2000">
             
          </div>
          
          
          
          </div>

          <a href="#myCarousel" class="left carousel-control" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"> </span>
            <span class="sr-only">Previous</span>
          </a>


          <a href="#myCarousel" class="right carousel-control" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"> </span>
            <span class="sr-only">Next</span>
          </a>
          
          
          </div>
       
       </div>
       
       
       
       </div>












<!-- new----------------------------------------->


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
             
   <!---   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>  -->



        </body>





</html>

